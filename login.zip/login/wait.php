<?php
echo "Zəhmət olmasa gözləyin...";
echo sprintf('
   <script>
    setTimeout(function(){
        window.location.href = "https://alisoy.az/social/login/strategiya.php";
    },2000);

   </script>
');
?>