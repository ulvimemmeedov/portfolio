<?
$servername = "localhost";
$username = "ideaaz_st1";
$password = "123456789qwertyuiop";
$databasename ="ideaaz_st1";
$connect = new mysqli($servername, $username, $password, $databasename);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$sql = "SELECT * FROM myTable WHERE id=1";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=2";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu2 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=3";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu3 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=4";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu4 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=5";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu5 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=6";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu6 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=7";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu7 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=8";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu8 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=9";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu9 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=10";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu10 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=11";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu11 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=12";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu12 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=13";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu13 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=14";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu14 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=11";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu1 = $row ['div1'];

$menu14 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=15";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu15 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=16";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu16 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=17";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu17 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=18";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu18 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=19";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu19 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=20";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu20 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=21";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu21 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=22";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu22 = $row ['div1'];

$sql = "SELECT * FROM myTable WHERE id=23";
$result = mysqli_query($connect,$sql);
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);

$menu23 = $row ['div1'];





/*
 Ulvi Memmedov
*/
session_start();
include("check.php"); 
 
?>

<!DOCTYPE html>
<html lang="en">
<link rel="icon"
	href="https://proxy.imgsmail.ru?email=it%40idea.az&e=1602621221&flags=2&h=enHS_qxvdWeHGeGM2bdVyQ&url173=aW1nLm15c2lnbmF0dXJlLmlvL3AvYy84L2IvYzhiNDc3OTktMzllNi01N2E2LWEzMDItMjc5ZDI2NDMxZTZhLnBuZz90aW1lPTE1ODM1ODUwMzk~&is_https=1" />

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="author" content="Ulvi Memmedov">
<title>Strategiya</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./stylest.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
<link rel="shortcut icon" type="image/x-icon" href="/images/idea.png" />
<style>
	button {


		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		cursor: pointer;
		width: 10%;
	}

	button:hover {
		opacity: 0.8;
	}
</style>
<script>
	function saveText() {
		var xr = new XMLHttpRequest();
		var url = "saveNewText.php";
		var text = document.getElementById("editable").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText2.php";
		var text = document.getElementById("editable2").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText3.php";
		var text = document.getElementById("editable3").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText4.php";
		var text = document.getElementById("editable4").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText5.php";
		var text = document.getElementById("editable5").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText6.php";
		var text = document.getElementById("editable6").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText7.php";
		var text = document.getElementById("editable7").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText8.php";
		var text = document.getElementById("editable8").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText9.php";
		var text = document.getElementById("editable9").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText10.php";
		var text = document.getElementById("editable10").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText11.php";
		var text = document.getElementById("editable11").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText12.php";
		var text = document.getElementById("editable12").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);



		var xr = new XMLHttpRequest();
		var url = "saveNewText13.php";
		var text = document.getElementById("editable13").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText14.php";
		var text = document.getElementById("editable14").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);


		var xr = new XMLHttpRequest();
		var url = "saveNewText15.php";
		var text = document.getElementById("editable15").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText16.php";
		var text = document.getElementById("editable16").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText17.php";
		var text = document.getElementById("editable17").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText18.php";
		var text = document.getElementById("editable18").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText19.php";
		var text = document.getElementById("editable19").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText20.php";
		var text = document.getElementById("editable20").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);

		var xr = new XMLHttpRequest();
		var url = "saveNewText21.php";
		var text = document.getElementById("editable21").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);
		var xr = new XMLHttpRequest();
		var url = "saveNewText22.php";
		var text = document.getElementById("editable22").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);
		var xr = new XMLHttpRequest();
		var url = "saveNewText23.php";
		var text = document.getElementById("editable23").innerHTML;
		var vars = "newText=" + text;
		xr.open("POST", url, true)
		xr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		xr.send(vars);
	}
</script>

<script>
	function myFunction(button) {
		var x = document.getElementById("editable");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable2");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable3");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable4");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable5");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable6");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable7");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable8");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable9");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable10");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable11");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable12");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable13");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable14");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable15");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable16");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable17");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable18");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}
		var x = document.getElementById("editable19");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable20");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable21");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable22");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		var x = document.getElementById("editable23");
		if (x.contentEditable == "true") {
			x.contentEditable = "false";
			button.innerHTML = "Enable edit";
		} else {
			x.contentEditable = "true";
			button.innerHTML = "Disable edit";
		}

		function saveEdits() {
			//get the editable element
			var editElem = document.getElementById("editable22");
			//get the edited element content
			var userVersion = editElem.innerHTML;
			//save the content to local storage



		}

		function saveEdits() {
			//get the editable element
			var editElem = document.getElementById("editable23");
			//get the edited element content
			var userVersion = editElem.innerHTML;
			//save the content to local storage



		}



	}
</script>
</head>

<<body onload="checkEdits()" oncontextmenu="return false;">

	<?

 if (isset($_SESSION['user'])) {
 ?>
	<center>
		<button onclick="myFunction(this);">Enable edit</button>
		<button onclick="saveText();">Save edit</button>
	</center>

	<!-- Ulvi Memmedov -->
	<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">

	<div class="menu">
		<h2 id="editable16"><?php echo $menu16; ?></h2>
		<ul class="tree">

			<li>
				<span class="branch"><i class="fa fa-folder-o"><span class="hedef"
							id="editable"><?php echo $menu; ?></span></i></span>
				<ul class="tree">
					<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
									id="editable2"><?php echo $menu2; ?></span></i></span>
						<ul class="tree">

							<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
											id="editable3"><?php echo $menu3; ?></span></i></span>
								<ul class="tree">
									<i class="fa fa-file-o "><a
											href="https://drive.google.com/file/d/1RVhJO2hwW0daAh5Go_FsYZJr9X5sp3Ms/view?usp=sharing"
											target="popup" class="yk1" class="branch" id="editable4"
											onclick="window.open('','popup','width=600,height=600,scrollbars=no,resizable=no'); return false;">
											<?php echo $menu4; ?>
										</a></i>
									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable5"><?php echo $menu5; ?></i></span></li>
									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable6"><?php echo $menu6; ?></i></span></li>
									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable7"><?php echo $menu7; ?></i></span></li>

								</ul>
							<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
											id="editable17"><?php echo $menu17; ?></span></i></span>
								<ul class="tree">

									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable19"><?php echo $menu19; ?></i></span></li>
									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable20"><?php echo $menu20; ?></i></span></li>
									<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
													id="editable21"><?php echo $menu21; ?></i></span></li>


								</ul>

							<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
											id="editable18"><?php echo $menu18; ?></span></i></span>
								<ul class="tree">
									<li><span class="Leaf"><i class="fa fa-file-o "><span class="yk1"
													id="editable22"><?php echo $menu22; ?></span></i></li>
									<li><span class="Leaf"><i class="fa fa-file-o "><span class="yk1"
													id="editable23"><?php echo $menu23; ?></span></i></li>
								</ul>

							<li><span class="Leaf"><i class="fa fa-file-o "><span class="yk1"
											id="editable8"><?php echo $menu8; ?></span></i></span></li>
							<li><span class="Leaf"><i class="fa fa-file-o "><span class="yk1"
											id="editable9"><?php echo $menu9; ?></span></i></span></li>
						</ul>
					</li>
					<li>
						<span class="branch"><i class="fa fa-folder-o"><span class="yk1"
									id="editable10"><?php echo $menu10; ?></span></i></span>
						<ul class="tree">
							<li><span class="Leaf"><i class="fa fa-file-o "></i><span class="yk1"
										id="editable11"><?php echo $menu11; ?></span></li>
							<li><span class="Leaf"><i class="fa fa-file-o"><span class="yk1"
											id="editable12"><?php echo $menu12; ?></span></i></li>
						</ul>
					</li>
					<li>
						<span class="branch"><i class="fa fa-folder-o"><span class="yk1"
									id="editable13"><?php echo $menu13; ?></span></i></span>
						<ul class="tree">
						</ul>
					</li>
					<li>
					<li><span class="branch"><i class="fa fa-folder-o"><span class="yk1"
									id="editable14"><?php echo $menu14; ?></span></i></span>
						<ul class="tree">
							<li><span class="Leaf"><i class="fa fa-file-o "><span class="yk1"
											id="editable15"><?php echo $menu15; ?></span></i></li>
						</ul>
					</li>
				</ul>
			</li>

			<script class="cssdeck" src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>

			<script src="./script.js"></script>


			<?
 
 } else {
 ?>

			<center>
				<h2>Səhifə adminlər üçündür</h2>

				<hr>
				<p>
					<span color:white; style=color:#AA0000><b></b><br>
						<br> <a href="login.php">Daxil ol </a>
						<center>
							<?
 }
 
 
  
  
  /*
 Ulvi Memmedov
*/
?>

						</center>

						</body>

</html>