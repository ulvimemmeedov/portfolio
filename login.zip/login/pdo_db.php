<?
/*
 Ulvi Memmedov
*/
try{
    $db = new pdo( 'mysql:host='.$hosting.';dbname='.$database,$database_user,$database_password,
                    array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
   
}
catch(PDOException $ex){
    
	die("Unable to Connect");
}
?>