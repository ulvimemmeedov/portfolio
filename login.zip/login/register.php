<?php
/*
 Ulvi Memmedov
*/
session_start();
include("check.php");


if (isset($_POST["register"])) {
$_POST["email"]=trim($_POST["email"]);

do {

if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)===false or !preg_match('/@.+\./', $_POST["email"])) {$error="Invalid Email";break;}
if ($_POST["password"]!=$_POST["confirm_password"]) {$error="Password mismatch";break;}
if (strlen($_POST["password"])<8) {$error="Password too short (minimum 8 character)";break;}


$sql = $db->prepare("SELECT * FROM utenti WHERE email=?");
$sql->bindParam(1, $_POST["email"]);
$sql->execute();
$exists=$sql->rowCount();

if ($exists) {$error="Email Already Registered";break;}


$hash = password_hash($_POST['password'].PEPPER, PASSWORD_DEFAULT, ['cost' => 12]);

try {
$sql = $db->prepare("INSERT INTO utenti (email,password) VALUES (? ,?)");
$sql->bindParam(1, $_POST["email"]);
$sql->bindParam(2, $hash);
$sql->execute();
} catch (PDOException $e) {
$error="Error during ";break;
}

$registered=1;

} while(0);

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Qeydiyyat səhifəsi</title>
	<link href='http://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
    <link href=style.css  rel='stylesheet' type='text/css'>
	</head>
<body>

	<div class="header">
		<a href="/">idea</a>
	</div>

	
		<br>


	<h1>Qeydiyyat edin </h1>	
	
    <br><p style=color:#C00><b><?= $error ?></b></p>
	<?php
	
	if(!$registered) { ?>
	<form action="register.php" method="POST">
		<input type="email" required placeholder="Email" name="email" value=<?=$_POST["email"];?>>
		<input type="password" required placeholder="Şifrə" name="password" pattern=".{8,}" minlength="8">
		<input type="password" required placeholder="Şifrəni yenidən daxil edin" name="confirm_password">
		<input type="submit" name=register>
	</form>
	<?
	} else {
	?>
	<br><br><p>Qeydiyyat ugurla yerine yetirildi</p><a href=login.php>Giriş səhifəsi</a>.
	<?
	}
	?>
</body>
</html>
<?




?>
<script>
var password = document.getElementsByName("password")[0]
  , confirm_password = document.getElementsByName("confirm_password")[0];

function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords Don't Match");
  } else {
    confirm_password.setCustomValidity('');
  }
}

password.onchange = validatePassword;
confirm_password.onkeyup = validatePassword;
</script>
