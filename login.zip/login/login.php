<?php
/*
 ulvi Memmedov
*/
session_start();

 
include("check.php"); 



if (isset($_SESSION['user'])) {

$message="You are already Logged in. Enjoy contents <a href=content.php>here</a> ";//or stay in this page and show a message
}


if (isset($_POST["login"])) {

$_POST["email"]=trim($_POST["email"]);

do {

if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)===false or !preg_match('/@.+\./', $_POST["email"])) {$message="Invalid Email";break;}


$sql = $db->prepare("SELECT data FROM log_accessi WHERE ip='".$_SERVER['REMOTE_ADDR']."' and accesso=0 and data>date_sub(now(), interval 10 minute) ORDER BY data DESC");
$sql->execute();
$attempts=$sql->rowCount();
$last=$sql->fetchColumn();
	
$last=strtotime($last);
$delay=min(max(($attempts-3),0)*2,30); 
if (time()<($last+$delay)) {$message="Too many attempts, wait $delay seconds before retry";break;}



$sql = $db->prepare("SELECT * FROM utenti WHERE email=?");
$sql->bindParam(1, $_POST["email"]);
$sql->execute();
$rows = $sql->fetch(PDO::FETCH_ASSOC);	



$checked = password_verify($_POST['password'].PEPPER, $rows["password"]);
if ($checked) { 
    $message='password correct<br>enjoy content <a href=index.php>here</a>';
	$_SESSION['user'] = $rows["id"];
	
	
	if ($_POST["remember"]=="true") {
	
	
	 $selector = aZ();
	 $authenticator = bin2hex(random_ver(33));
	   $res=$db->prepare("INSERT INTO auth_tokens (selector,hashedvalidator,userid,expires,ip) VALUES (?,?,?,FROM_UNIXTIME(".(time() + 864000*7)."),?)");
	   $res->execute(array($selector,password_hash($authenticator, PASSWORD_DEFAULT, ['cost' => 12]),$rows['id'],$_SERVER['REMOTE_ADDR']));			

setcookie(
        'remember',
         $selector.':'.base64_encode($authenticator),
         (time() + 864000*7), 
         '/',
         WEBSITE,
         false, 
         false  
    );
}


header("location:content.php");

	
} else {
    $message=($attempts>1)?"Wrong credentials ($attempts attempts)":"Wrong credentials retry";
}



$sql = $db->prepare("INSERT INTO log_accessi (ip,mail_immessa,accesso) VALUES (? ,? ,?)");
$sql->bindParam(1, $_SERVER['REMOTE_ADDR']);
$sql->bindParam(2, $_POST["email"]);
$sql->bindParam(3, $checked);
$sql->execute();

}while(0);

}



?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Giris</title>
	<link href='http://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
	<link href=style.css  rel='stylesheet' type='text/css'>
	<style>
	 a{
	       text-decoration: none;
	       color:black;

	 }
	</style>
	</head>
<body>

	

	<? if (empty($_SESSION["user"])) {
	?>
	<h1>Giriş</h1>
	<br><p style=color:#C00><b><?= $message ?></b></p>
	<form action="login.php" method="POST">
		
		<input type="email" required placeholder="Email" name="email">
		<input type="password" required placeholder="Şifrə" name="password">
		<input type=checkbox name=remember value=true> Məni xatırla
		<br><br><input type="submit" name=login>

	</form>
	<br><span><a href = "mailto: it@idea.az"> Şifrəni unutmusunuzsa dəstək</a></span>
	<?
	}
	


?>
</body>
</html>