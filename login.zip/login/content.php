<?
/*
 Ulvi Memmedov
*/
session_start();
include("check.php"); 
 
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link href='http://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
	<link href=style.css  rel='stylesheet' type='text/css'>
	</head>
<body>

	<div class="header">
		<a href="/"><br><small>idea</small></a>
	</div>
	<center>
	
	
<?

 if (isset($_SESSION['user'])) {
 ?>
<h1>
    Xoş Gəldiniz
</h1>
<span><a href="register.php">İstifadəçi qeydiyyat etmək</a></span><br> <br> 

  <a href=wait.php>Strategiya</a><br><br>
  
  <a href="index.php?logout=1">Çıxış edin</a>
 <?
 
 } else {
 ?>
 
 <h1>sehife ancax adminler ucundur</h1>
 <hr><p>
  <a href="login.php">daxil olun</a> 
   <?
 }
 
 

  
  /*
 Ulvi Memmedov
*/
?>

</center>
</body>
</html>
 
 