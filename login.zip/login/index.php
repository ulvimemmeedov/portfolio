<?

/*
 Ulvi Memmedov
*/

session_start();
include("check.php"); 


?>
<!DOCTYPE html>
<html>
<head>
	<title>Ana Səhifə</title>
	<link href='http://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
	<link href=style.css  rel='stylesheet' type='text/css'>
	</head>
<body>

	<div class="header">
		<a href="/">idea</a>
	</div>
	<center>
	<h1>idea infasutruktur</h1>
	
	<p style=max-width:500px><small>
	
	</small></p>
	<hr><p>
<?

 if (isset($_SESSION['user'])) {
   echo '<span style=color:#009900><b>Siz daxil olmusunuz</b></span></br>
   </br> <a href=content.php>Admin bölməsi</a><br> <a href="register.php"></a><br> <a href="index.php?logout=1">Çıxış edin</a>';
 
 } else {
   echo '<span style=color:#AA0000><b>Zəhmət olmasa</b></span> <a href="login.php">Giriş edin</a><br><br>';
 }

 

 

 
?>
</p>
</center>
</body>
</html>

 