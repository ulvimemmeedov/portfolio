<?php
$servername = "localhost";
$username = "ideaaz_st1";
$password = "123456789qwertyuiop";
$databasename ="ideaaz_st1";

$connect = new mysqli($servername, $username, $password, $databasename);



$newText = $_POST['newText'];

if ($newText != ""){
$sql = "UPDATE myTable SET div1 = '".$newText."' WHERE id=7 ";  
$result = mysqli_query($connect,$sql);
    
}

?>